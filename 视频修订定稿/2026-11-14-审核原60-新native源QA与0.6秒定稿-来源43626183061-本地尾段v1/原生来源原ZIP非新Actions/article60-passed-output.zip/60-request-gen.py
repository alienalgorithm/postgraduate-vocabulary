#!/usr/bin/env python3
# Pure data frozen from the current approved JSON; shared helper/checkers unchanged.
import os
import sys

S = [(1,
  [[[('On 29 May 1919,', '1919年5月29日，'),
     ('as a total', '一次全'),
     ('**eclipse**', '**日食**(eclipse)'),
     ('**obscured**', '**遮蔽了**(obscured)'),
     ('the sun,', '太阳，')],
    '（as…：引导时间状语从句，“当……时”）'],
   [[('two', '两支'),
     ('British', '英国'),
     ('**expeditions**', '**考察队**(expeditions)'),
     ('photographed', '拍摄了'),
     ('stars in its **apparent**', '天空中**看似**(apparent)位于太阳'),
     ('**vicinity**.', '**附近**(vicinity)的恒星。')],
    '（in its apparent vicinity：后置定语，修饰 stars；\nits 指 the sun）']]),
 (1,
  [[[('Arthur Eddington', '阿瑟·爱丁顿'),
     ('**observed**', '**观测**(observed)'),
     ('from Príncipe,', '于普林西比岛，'),
     ('an island', '这是一座岛，'),
     ('off West Africa;', '位于西非外海；')],
    '（an island off West Africa：同位语，补充说明 Príncipe）'],
   [[('Crommelin and Davidson', '克罗姆林和戴维森则'),
     ('from Sobral,', '在索布拉尔，'),
     ('in north-eastern **Brazil**.', '位于**巴西**(Brazil)东北部。')],
    '（Crommelin and Davidson from Sobral：\n承前省略了 observed）']]),
 (1,
  [[[('They', '他们'),
     ('were testing', '要检验'),
     ("**general relativity**'s", '**广义相对论**(general relativity)的一个'),
     ('**bold**', '**大胆的**(bold)'),
     ('prediction', '预言，')]],
   [[("that the sun's", '也就是太阳的'),
     ('**gravity**', '**引力**(gravity)'),
     ('would **deflect** starlight.', '会**使**(deflect)星光**偏折/偏离方向**(deflect)。')],
    "（that the sun's gravity…：同位语从句，\n说明 prediction 的内容）"]]),
 (2,
  [[[('On 6 November,', '11月6日，'),
     ('at a **joint** meeting of the **Royal** Society and the **Royal** Astronomical Society,',
      '英国**皇家**(Royal)学会与**皇家**(Royal)天文学会召开**联席**(joint)会议，')],
    '（of the Royal Society…：of 结构作后置定语，修饰 meeting）'],
   [[('the **findings**', '其观测**结果**(findings)'),
     ('were **hailed as**', '被**盛赞为**(hailed as)'),
     ('confirming it.', '证实了这一预言。')],
    '（be hailed as：被盛赞为，被誉为；\nit 指上文的预言）\n（1919年11月6日，日食观测结果在两学会的联席会议上公布，\n人们认为它支持了爱因斯坦的预言：\n太阳引力会使星光偏折。）']]),
 (2,
  [[[('The Times', '《泰晤士报》'),
     ('**proclaimed**', '**宣告了**(proclaimed)'),
     ('a "**Revolution** in Science";', '一场“科学**革命**(Revolution)”；')]],
   [[('a New York Times', '《纽约时报》的'),
     ('**headline**', '**标题**(headline)'),
     ('read', '写着'),
     ('"Lights All **Askew** in the Heavens".', '“天上的光全**歪了**(Askew)”。')],
    '（read：（文字）写着）']]),
 (2,
  [[[('Almost', '几乎'),
     ('**overnight**,', '**一夜之间**(overnight)，'),
     ('Einstein, **eminent** among **physicists**,', '在**物理学家**(physicists)中**卓越的**(eminent)爱因斯坦')],
    '（eminent among physicists：插入语，补充说明 Einstein）'],
   [[('became', '成了'), ('a global', '一位全球性的'), ('**celebrity**.', '**名人**(celebrity)。')]]]),
 (3,
  [[[('Stockholm', '斯德哥尔摩却'), ('proved harder', '没那么容易'), ('to **dazzle**.', '被**眩惑**(dazzle)。')],
    '（Stockholm：指斯德哥尔摩的诺贝尔奖评审机构；\n'
    'prove＋形容词：结果是……）\n'
    '（此处 to dazzle = 被眩惑 / 被迷晕。\n'
    'dazzle 本意是强光刺眼，\n'
    '引申为因光环/声望而让人晕头转向、盲目崇拜）']]),
 (3,
  [[[('The Nobel physics committee', '诺贝尔物理学委员会'),
     ('valued', '看重的是'),
     ('**rigorous**', '**严格的**(rigorous)'),
     ('**experimental**', '**实验**(experimental)'),
     ('**confirmation**,', '**证实**(confirmation)，')]],
   [[('and', '而'),
     ('**committee**', '**委员会**(committee)'),
     ('member', '成员'),
     ('Allvar Gullstrand,', '阿尔瓦·古尔斯特兰德，'),
     ('a Nobel-winning', '一位获得过诺贝尔奖的'),
     ('eye', '眼科'),
     ('**specialist**,', '**专家**(specialist)，')],
    '（a Nobel-winning eye specialist：同位语，\n补充说明 Allvar Gullstrand）'],
   [[('**deemed**', '**认定**(deemed)'),
     ('the **empirical** support for relativity', '相对论的**实证**(empirical)支持'),
     ('**insufficient**.', '**不足**(insufficient)。')],
    '（deem A insufficient：认定 A 不足；\nfor relativity：后置定语，修饰 support）']]),
 (3,
  [[[('Since', '由于'),
     ('no **nomination**', '没有一项**提名**(nomination)'),
     ('**fulfilled**', '**符合**(fulfilled)'),
     ("Nobel's", '诺贝尔定下的'),
     ('**criteria**,', '**标准**(criteria)，')]],
   [[('the 1921 prize', '1921年的奖'),
     ('was **reserved**', '被**保留**(reserved)'),
     ('for a year,', '一年，'),
     ('as the **statutes**', '这是**章程**(statutes)'),
     ('**permit**.', '所**允许**(permit)的。')],
    '（as the statutes permit：as 引导方式状语从句，\n按照章程所允许的办法）']]),
 (4,
  [[[('On 9 November 1922', '1922年11月9日，'),
     ('the Royal Swedish Academy of Sciences', '瑞典皇家科学院'),
     ('**conferred** it **on** Einstein,', '把这个奖**授予**(conferred on)爱因斯坦，')],
    '（confer A on B：把 A 授予 B；it 指1921年的奖）'],
   [[('**citing**', '**表彰**(citing)'),
     ('his services to theoretical physics,', '他对理论物理学的贡献，'),
     ('especially', '尤其是'),
     ('his discovery of the **law** of the photoelectric effect.', '他发现了光电效应**定律**(law)。')],
    '（citing…：现在分词短语作伴随状语；\nespecially his discovery…：补充说明 services）']]),
 (4,
  [[[('That law,', '这条定律'),
     ('which **governs**', '**规定了**(governs)'),
     ('how light', '光如何'),
     ('**ejects** **electrons** from metal,', '把**电子**(electrons)从金属中**打出/击出**(ejects)，')],
    '（which governs…：非限制性定语从句，\n修饰 That law；\nhow light…：宾语从句）'],
   [[('helped', '曾帮助'),
     ('**underpin**', '**奠定**(underpin)'),
     ('**quantum**', '**量子**(quantum)'),
     ('theory.', '理论的基础。')],
    '（help underpin：帮助奠定……的基础）']]),
 (4,
  [[[('A letter the next day', '第二天的一封信'),
     ('**clarified**', '**澄清**(clarified)，'),
     ('that the prize', '此奖'),
     ('**took no account of**', '**并未考虑**(took no account of)'),
     ('relativity.', '相对论。')],
    '（the next day：后置定语，修饰 letter；\ntake no account of：不考虑）']]),
 (4,
  [[[('Einstein,', '爱因斯坦'),
     ('then', '当时正'),
     ('**aboard**', '**乘**(aboard)'),
     ('a **steamer** **bound for** Japan,', '一艘**开往**(bound for)日本的**轮船**(steamer)，')],
    '（then aboard…：插入语，补充说明 Einstein；\nbound for Japan：后置定语，修饰 steamer）'],
   [[('would **miss**', '将**错过**(miss)'),
     ('the December', '12月的颁奖'),
     ('**ceremony**.', '**典礼**(ceremony)。')]]]),
 (5,
  [[[('On 11 July 1923,', '1923年7月11日，'),
     ('in Gothenburg, Sweden,', '在瑞典哥德堡，'),
     ('he', '他'),
     ('**delivered**', '**发表了**(delivered)'),
     ('his Nobel', '他的诺贝尔'),
     ('**lecture**', '**演讲**(lecture)，')]],
   [[('before a **congress** of Nordic scientists,', '面向北欧自然科学家**大会**(congress)，')],
    '（before：在……面前；\nof Nordic scientists：of 结构作后置定语，修饰 congress）'],
   [[('**devoting** it **to**', '**专门**(devoting to)讲'),
     ('the **fundamental** ideas and problems of relativity.', '相对论的**基本**(fundamental)思想与问题。')],
    '（devote A to B：把 A 专门用于 B；it 指 lecture）']]),
 (5,
  [[[('The theory the committee **looked past**', '委员会**绕开不看**(looked past)的那个理论，'),
     ('reached a Nobel **podium** **after all**,', '**终究还是**(after all)登上了诺贝尔的**讲台**(podium)，')],
    '（the committee looked past：定语从句，省略了关系代词，修饰 theory；\nlook past：忽视，绕开不看）'],
   [[('carried there by the man the prize had **honoured**.', '把它带上去的，正是这个奖所**嘉奖**(honoured)的爱因斯坦。')],
    '（通俗解读：当时诺贝尔奖委员会的老学究们觉得相对论太颠覆了，\n'
    '不敢颁奖，就一直装作没看见。但兜兜转转，\n'
    '爱因斯坦最后还是拿了诺贝尔奖（靠光电效应），狠狠打了委员会的脸。）\n'
    '（简述：▸成名：1919年日食观测被誉为证实太阳引力会使星光偏折，这一相对论预言让爱因斯坦迅速举世闻名。▸分歧：委员古尔斯特兰德认为相对论证据不足；1921年因无提名达标，物理学奖按章程保留一年。▸授奖：1922年，保留的1921年度物理学奖授予爱因斯坦，表彰理论物理贡献，尤其是发现光电效应定律。▸区别：光电效应指光使金属释放电子，这一定律帮助奠定量子理论基础；授奖决定次日的信件明确：该奖不考虑相对论。▸演讲：爱因斯坦赴日错过颁奖典礼；1923年，他的诺贝尔演讲却专讲相对论，让被奖项绕开的理论登上讲台。）']])]

out = {'no': '60',
 'title_en': 'The Scientific Giant Who Changed the World',
 'title_zh': '爱因斯坦的诺奖之路',
 'title_fx': {'hl': ['Giant', 'World'], 'ghost': []},
 'sentences': [],
 '核对确认': {'合组': {"S3 general relativity's": '对齐不了：general relativity 是术语“广义相对论”，拆开不通',
                 'S8 and committee member': '对齐不了：committee member 是一个词“委员”，拆开不通',
                 'S12 took no account of': '对齐不了：take no account of 是固定说法“不考虑”，拆开不通',
                 'S1 stars in its apparent vicinity': '对齐不了：in its apparent vicinity 是后置定语，修饰 '
                                                      'stars，中文“看似位于太阳附近的恒星”定语必须提前',
                 'S3 would deflect starlight': '对齐不了：deflect starlight '
                                               '中文“使星光偏折”，宾语必须放到动词前（文章定稿原文“会使经过它附近的星光偏折”）',
                 'S4 at a joint meeting of the Royal Society and the Royal Astronomical Society': '对齐不了：of the '
                                                                                                  'Royal '
                                                                                                  'Society… 是 '
                                                                                                  'of '
                                                                                                  '结构作后置定语，中文“英国皇家学会与皇家天文学会召开联席会议”机构名必须提前，机构名不能拆',
                 'S6 Einstein, eminent among physicists': '对齐不了：eminent among physicists '
                                                          '是插入语，中文“在物理学家中卓越的爱因斯坦”定语必须提前；两个重点词中文先后与英文相反',
                 'S7 proved harder': '对齐不了：prove＋形容词比较级（proved harder to…），中文“没那么容易”是整体说法，拆开不通',
                 'S8 The Nobel physics committee': '对齐不了：机构名“诺贝尔物理学委员会”，拆开不通',
                 'S8 the empirical support for relativity': '对齐不了：for relativity 是后置定语，修饰 '
                                                            'support，中文“相对论的实证支持”必须提前',
                 'S10 the Royal Swedish Academy of Sciences': '对齐不了：机构名“瑞典皇家科学院”，拆开不通',
                 'S10 conferred it on Einstein': '对齐不了：confer A on B 被 it 隔开，中文“把这个奖授予爱因斯坦”，只能整组',
                 'S10 his services to theoretical physics': '对齐不了：to theoretical physics 是后置定语，修饰 '
                                                            'services，中文“他对理论物理学的贡献”必须提前',
                 'S10 his discovery of the law of the photoelectric effect': '对齐不了：层层后置的 of '
                                                                             '结构，中文“他发现了光电效应定律”语序必须倒过来，术语不能拆',
                 'S11 ejects electrons from metal': '对齐不了：eject A from B 中文“把电子从金属中打出”，动词必须放到最后；两个重点词中文先后与英文相反',
                 'S12 A letter the next day': '对齐不了：the next day 是后置定语，修饰 letter，中文“第二天的一封信”必须提前',
                 'S13 a steamer bound for Japan': '对齐不了：bound for Japan 是后置定语，修饰 '
                                                  'steamer，中文“一艘开往日本的轮船”必须提前；两个重点词中文先后与英文相反',
                 'S14 before a congress of Nordic scientists': '对齐不了：of Nordic scientists 是 of 结构作后置定语，修饰 '
                                                               'congress，中文“北欧自然科学家大会”必须提前',
                 'S14 the fundamental ideas and problems of relativity': '对齐不了：of relativity 是 of '
                                                                         '结构作后置定语，中文“相对论的基本思想与问题”必须提前',
                 'S15 The theory the committee looked past': '对齐不了：the committee looked past 是省略关系代词的定语从句，修饰 '
                                                             'theory，中文“委员会绕开不看的那个理论”必须提前',
                 'S15 reached a Nobel podium after all': '对齐不了：after all 中文“终究”必须放到动词前',
                 'S15 carried there by the man the prize had honoured': '对齐不了：被动结构加定语从句，中文“把它带上去的，正是这个奖所嘉奖的爱因斯坦”语序必须整个倒过来'},
          '对齐': {'S4-1 at a joint meeting of the Roya': 'of the Royal Society… 是 of 结构作后置定语，修饰 '
                                                        'meeting，机构名必须提前，不能拆',
                 'S5-2 "Lights All Askew in the Heave': '报纸标题原文，中文“天上的光全歪了”整句意译，标题不能拆',
                 'S8-3 the empirical support for rela': 'for relativity 是后置定语，修饰 support，中文“相对论的实证支持”必须提前',
                 'S10-1 the Royal Swedish Academy of S': '机构名“瑞典皇家科学院”，拆开不通',
                 'S10-2 his services to theoretical ph': 'to theoretical physics 是后置定语，修饰 '
                                                         'services，中文“对理论物理学的贡献”必须提前',
                 'S10-2 his discovery of the law of th': '层层后置的 of 结构，中文“他发现了光电效应定律”语序必须倒过来，术语不能拆',
                 'S12-1 A letter the next day': 'the next day 是后置定语，修饰 letter，中文“第二天的一封信”必须提前',
                 'S13-1 a steamer bound for Japan,': 'bound for Japan 是后置定语，修饰 steamer，中文“开往日本的轮船”必须提前',
                 'S14-2 before a congress of Nordic sc': 'of Nordic scientists 是 of 结构作后置定语，修饰 congress，中文必须提前',
                 'S14-3 the fundamental ideas and prob': 'of relativity 是 of 结构作后置定语，中文“相对论的基本思想与问题”必须提前',
                 'S15-1 The theory the committee looke': '省略关系代词的定语从句修饰 theory，中文“委员会绕开不看的那个理论”定语必须提前',
                 'S15-1 reached a Nobel podium after a': 'after all 中文“终究”必须放到动词前',
                 'S15-2 carried there by the man the p': '被动结构加定语从句，中文“把它带上去的，正是这个奖所嘉奖的爱因斯坦”语序必须整个倒过来',
                 'S1-2 stars in its apparent': 'in its apparent vicinity 是后置定语，修饰 stars，中文定语必须提前'},
          '方向': {'S14-2 before→面向北欧自然科学家大会，': 'before a congress 的 before 是“在……面前”（场合），不是时间先后；中文“面向……大会”，方向一致',
                 'S15-1 after→终究登上了诺贝尔的讲台，': 'after all 是“终究，毕竟”，不是时间先后；中文“终究”，方向一致',
                 'S15-1 after→终究还是登上了诺贝尔的讲': 'after all已按用户075完整两词重点，本文终究还是为让步性收束，不是时间方向after；对应终究还是四字语义一致。'},
          '短语': {'S2 observed … from': '不是搭配：from Príncipe 只表示观测地点（从普林西比岛观测），observe 单独就是“观测”',
                 'S8 deemed … for': '不是搭配：for 属于 support for relativity（对相对论的支持），和 deemed 无关',
                 'S9 fulfilled … for': '不是搭配：for 属于 reserved for a year，和 fulfilled 无关',
                 'S9 reserved … for': '不是搭配：for a year 只表示时长（保留一年），reserve 单独就是“保留”',
                 'S10 conferred … to': '不是搭配：to 属于 his services to theoretical physics（对理论物理学的贡献），confer 的搭配是 '
                                       'on，已整体标',
                 'S10 citing … of': '不是搭配：of 属于 his discovery of the law（发现了……定律），和 citing 无关',
                 'S10 citing … to': '不是搭配：to 属于 his services to theoretical physics，和 citing 无关',
                 'S11 governs … from': '不是搭配：from 属于 ejects electrons from metal，和 governs 无关',
                 'S11 ejects … from': '不是搭配：from metal 只表示来源（从金属中），eject 单独就是“打出”，同 S2 observed … from',
                 'S12 clarified … of': '不是搭配：of 属于 took no account of（不考虑，已整体标为重点词），和 clarified 无关',
                 'S14 delivered … of': '不是搭配：of 属于 a congress of Nordic scientists（后置定语），和 delivered 无关',
                 'S14 devoting … of': '不是搭配：of 属于 problems of relativity（后置定语），devote 的搭配是 to，已整体标',
                 'S1 a total eclipse': '不是搭配：速查表第一个意思就是“（日、月）食”，本文日食即此义；total 单独译“全”，沿用文章定稿“一次全日食”',
                 'S4 a joint meeting': '不是搭配：速查表第一个意思就是“联合的，共同的”，“联席会议”即两会联合开会，joint 单独即此义',
                 'S10 law … of': '不是搭配：law为物理定律名词，of the photoelectric '
                                 'effect是说明定律对象的普通后置介词短语；用户071仅指定law定律重点，不扩光电效应或of，词表law定律准确。'},
          '中文意思': {'S5 headline': '不是这个义项：本文 headline 是名词“（报纸的）标题”，不是动词“给……加标题”',
                   'S13 bound for': '不是被隔开：“开往日本的轮船”里的“的”是中文定语标记（对应 bound for Japan 作后置定语），意思“开往”已标全，沿用文章定稿'},
          '停顿位置': {'S11 law, / which @0.640': '2026-11-07 逐 2.5 ms 实测（S11 w）：law 的 ɔː 到 0.63（-14～-20 '
                                              'dB），0.64–0.66 是两词交界的低谷（-21～-25 dB），0.67 起 which 的 /w/ '
                                              '电平回升（-12.8→-7.6 dB）；law 元音结尾、which 滑音开头，两词浊音连读没有静音，停顿 0.640 '
                                              '落在低谷里，在两词之间',
                   'S13 Einstein, / then @0.795': '2026-11-07 逐 2.5 ms 实测（S13 w）：Einstein 的 n 衰减到 0.79（-38 '
                                                  'dB），0.795–0.805 -52.5～-53.8 dB 低谷，0.81 起 then 的 /ð/（-34 '
                                                  'dB）；停顿 0.795 正落在两词之间的低谷'},
          '非人声': {'2.63–2.65s': {'配音指纹': 'c51376cb90f5',
                                 '依据': '标题 w 2.255–2.28s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：标题 '
                                       'World 的 /ld/：l 浊音衰减（低频占比 -2 dB、周期 0.39），2.295（w）起 /d/ 除阻；是 /d/ '
                                       '的浊音闭塞，词的一部分',
                                 '实测': {'最响dB': -39.6, '重心Hz': 1918, '周期': 0.39, '低频dB': -2.0}},
                  '27.73–27.75s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S3 w 2.355–2.375s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S3 '
                                         'bold 的 /b/ 浊音杠（重心 0.3–0.5 kHz、低频占比 -1 dB），前面是删掉吸气后的数字静音，紧接 ɔʊ '
                                         '元音；词头的一部分',
                                   '实测': {'最响dB': -30.2, '重心Hz': 569, '周期': 0.37, '低频dB': -1.4}},
                  '45.96–45.98s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S5 w 2.615–2.63s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S5 '
                                         'Science 词内 n→s 过渡（前 -37～-47 dB 的 ən，后 -58 dB 短闭塞，再接 /s/ 5–6 '
                                         'kHz）；词的一部分',
                                   '实测': {'最响dB': -36.4, '重心Hz': 1971, '周期': 0.0, '低频dB': -1.5}},
                  '47.10–47.12s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S5 w 3.81–3.83s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S5 '
                                         'York 的 /k/ 除阻：ɔːɹ 衰减到 -70 dB 闭塞后爆出 15 ms（重心 2.6 kHz），之后静音到 '
                                         'Times；词尾塞音除阻',
                                   '实测': {'最响dB': -35.7, '重心Hz': 2020, '周期': 0.18, '低频dB': -6.5}},
                  '50.28–50.38s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S5 w 6.995–7.09s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S5 '
                                         'Heavens 词内 n→z 浊音过渡（重心 1–1.3 kHz、低频占比 -5 dB），后面紧接 /z/ 清化擦音 3–5.6 '
                                         'kHz；词的一部分',
                                   '实测': {'最响dB': -39.9, '重心Hz': 1740, '周期': 0.26, '低频dB': -5.7}},
                  '66.42–66.52s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S8 w 4.395–4.485s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S8 '
                                         'confirmation, 的 n 鼻音收尾（-28→-55 dB 连续衰减、重心 0.7–1.9 kHz、低频占比 -3 '
                                         'dB），与词之间没有低谷；词尾',
                                   '实测': {'最响dB': -35.3, '重心Hz': 1543, '周期': 0.28, '低频dB': -3.0}},
                  '69.25–69.27s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S8 w 7.30–7.32s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S8 '
                                         'Gullstrand 词中（-34～-49 dB 连续浊音、重心 0.7–1.6 kHz），在词的时长范围内；词的一部分',
                                   '实测': {'最响dB': -32.7, '重心Hz': 848, '周期': 0.27, '低频dB': -1.7}},
                  '71.83–71.89s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S8 w 9.875–9.93s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S8 '
                                         'specialist, 的 /t/ 除阻：/s/ 5.8 kHz 到 9.845（w），9.85–9.87 闭塞 -64 '
                                         'dB，9.875–9.91 爆出（重心 3.6–4.2 kHz），55 ms；词尾塞音除阻',
                                   '实测': {'最响dB': -31.1, '重心Hz': 3829, '周期': 0.2, '低频dB': -11.0}},
                  '72.29–72.31s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S8 w 10.29–10.305s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S8 '
                                         'deemed 的 /d/ 浊音杠（重心 0.3–0.5 kHz、低频占比 -1.6 dB），一直连到 iː；词头的一部分',
                                   '实测': {'最响dB': -31.0, '重心Hz': 914, '周期': 0.0, '低频dB': -1.6}},
                  '94.08–94.18s': {'配音指纹': 'c51376cb90f5',
                                   '依据': 'S10 w 7.02–7.125s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S10 '
                                         'Einstein, 的 n 鼻音收尾（-31～-50 dB 连续衰减到 -64 dB、低频占比 -3.5 dB），与词之间没有低谷；词尾',
                                   '实测': {'最响dB': -35.9, '重心Hz': 1876, '周期': 0.27, '低频dB': -3.5}},
                  '101.72–101.77s': {'配音指纹': 'c51376cb90f5',
                                     '依据': 'S10 w 14.74–14.785s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 '
                                           'w）：S10 effect. 句末 /t/ 除阻：闭塞 -68～-71 dB 后爆出（-29 dB、重心 2.8–3.3 '
                                           'kHz），45 ms 后衰减到静音；词尾塞音除阻',
                                     '实测': {'最响dB': -30.8, '重心Hz': 3216, '周期': 0.26, '低频dB': -12.2}},
                  '146.69–146.72s': {'配音指纹': 'c51376cb90f5',
                                     '依据': 'S15 w 7.97–8.01s：2026-11-07 逐 2.5 ms 实测（疑点清单 dossier_60，S 句 w）：S15 '
                                           'honoured. 的 /d/ 浊音闭塞（周期 0.62、重心 0.8–0.9 kHz、低频占比 -1.7 dB），之后 /d/ '
                                           '除阻；词尾的一部分',
                                     '实测': {'最响dB': -34.5, '重心Hz': 1036, '周期': 0.62, '低频dB': -1.7}}},
          '删除段': {'S1 raw 2.6613-2.9537': {'类型': '紧贴两头的非人声',
                                           '配音指纹': 'c51376cb90f5',
                                           '依据': '1919, 后停顿里的吸气（自动切点 非人声区间 S1 [2.59125, 2.88375, 紧贴两头]，删掉的最响 '
                                                 '-35.9 dB、无周期），切点在过零点、词本身不动'},
                  'S2 raw 2.5650-2.8786': {'类型': '紧贴词头的非人声',
                                           '配音指纹': 'c51376cb90f5',
                                           '依据': 'Príncipe, 后停顿里的吸气（非人声区间 S2 [2.54, 2.818667, 紧贴词头]，最响 -38.1 '
                                                 'dB），一直贴到 an 的起音，词头切在过零点'},
                  'S3 raw 2.1401-2.3700': {'类型': '紧贴词尾的非人声',
                                           '配音指纹': 'c51376cb90f5',
                                           '依据': "2026-11-07 逐 2.5 ms 实测（S3 w）：relativity's 的 /z/ 到 2.11（重心 "
                                                 '4–5.6 kHz），2.115–2.26 是吸气（-43～-51 dB、重心 2.0–2.6 kHz、低频 -15.7 '
                                                 'dB、周期 0.23，145 ms），2.26–2.345 残尾 -51～-62 dB，2.355 起 bold 的 '
                                                 '/b/ 浊音杠；/z/ 与吸气之间没有 -55 dB 低谷，起点切在过零点 2.120083，/z/ 本身不动'},
                  'S8 raw 4.4900-4.9633': {'类型': '紧贴词头的非人声',
                                           '配音指纹': 'c51376cb90f5',
                                           '依据': 'confirmation, 后停顿里的吸气（非人声区间 S8 [4.745, 4.963333, 紧贴词头]，最响 '
                                                 '-39.6 dB），贴到 and 的起音，词头切在过零点'},
                  'S9 raw 3.3900-3.8100': '2026-11-07 逐 10 ms 实测（S9 w）：criteria, 的 ə 到 3.37，3.38–3.42 '
                                          '静音（-55～-61 dB），3.43–3.73 是吸气（-39～-51 dB、低频 -12～-24 dB '
                                          '无周期），3.74–3.79 是孤立的声门噪声（-42～-55 dB），3.80–3.81 -60～-64 dB 低谷，3.82 起 '
                                          'the 的 /ð/；删掉的是吸气，两侧都在静音里',
                  'S10 raw 2.6250-2.8650': '2026-11-07 逐 10 ms 实测（S10 w）：1922 的 uː 衰减到 2.61（-55.7 dB '
                                           '低谷），2.62–2.80 是吸气（-40～-48 dB、低频 -10～-22 dB 无周期），2.81–2.87 '
                                           '孤立声门噪声（-46～-56 dB），2.88 -60 dB，2.89 起 the 的 /ð/；删掉的是吸气，两侧都在静音里'},
          '高亮': {'S3 第2块': {'开始读': 28.94,
                            '配音指纹': 'c51376cb90f5',
                            '依据': '2026-11-07 直接读 work_60/a.wav 逐 5 ms：prediction 衰减到 28.74（-65～-78 '
                                  'dB），28.745–28.935 是删掉吸气后的数字静音（非人声区间 S3 [3.361375, 3.6]），28.940 起 that 的 '
                                  '/ð/（-69→-49→-36 dB），28.965 起元音 -18 dB；开始读 28.94，高亮 28.93 差 0.01 s。办法甲 28.76 '
                                  '落在数字静音里，不对'}},
          '机器复听': {'S2': {'配音指纹': 'c51376cb90f5',
                          '依据': '2026-11-07：Príncipe 配音按读音改正 ˈpɹɪnsɪpə 读，识别器拼成 iprincipe / ipríncipa（专名拼写，前面的 '
                                'i 是 Island 后连读）；Crommelin 读 kɹˈɑːməlɪn，识别器拼成 cromelin（少一个 m，同音）。读音按已核实读音，非读错'},
                   'S5': {'配音指纹': 'c51376cb90f5',
                          '依据': '2026-11-07：headline read 是过去式，按语境读音读 /rɛd/，两个识别器都听成 red，正是要的读法（多音词核对 60 S5 '
                                'read）'},
                   'S8': {'配音指纹': 'c51376cb90f5',
                          '依据': '2026-11-07：Allvar Gullstrand 按读音改正 ˈɑːlvɑːɹ ɡˈʊlstɹænd 读，识别器拼成 alvar '
                                'gholstrand / alvar goldstrand（瑞典专名拼写，读音同已核实读音），非读错'}},
          '同词异译': {'eminent among：中声望卓著的/在': '不是两种译法：eminent among '
                                             '的意思“在……中声望卓著的”被“物理学家”隔开，“在”和“中声望卓著的”是同一个意思的两部分（T23）',
                   'deflect：使/偏折/偏离方向': '不是两种译法：deflect '
                                        '的完整本文义为使……偏折/偏离方向，中文使和偏折/偏离方向被星光隔开，是同一使动谓语的两部分（T23）；用户064明确指定此完整译文和两处同key标注。'},
          '是的': {'S15-1 是**(after all)登上了诺贝尔的**': '不是是……的强调句：是属于用户075指定完整重点终究还是的最后一个字，的属于后面的诺贝尔的讲台定语，程序跨过重点标签匹配到两段普通词；真实中文连续句为终究还是登上了诺贝尔的讲台。'},
          '口述': {'S15-2 觉得': '用户076明确提供完整评论“当时诺贝尔奖委员会的老学究们觉得相对论太颠覆了，不敢颁奖，就一直装作没看见”，觉得是评论中认为的谓语，不是语音填充词；按用户全文保留，通俗解读前缀标明评论。'}},
 '结尾解说': '简述',
 '高亮按实际开口': True,
 '高亮开口门槛': 40,
 '术语': {'Arthur Eddington': '阿瑟·爱丁顿',
        'Príncipe': '普林西比',
        'West Africa': '西非',
        'Crommelin': '克罗姆林',
        'Davidson': '戴维森',
        'Sobral': '索布拉尔',
        'Brazil': '巴西',
        'British': '英国',
        'Royal Society': '皇家学会',
        'Royal Astronomical Society': '皇家天文学会',
        'The Times': '《泰晤士报》',
        'New York Times': '《纽约时报》',
        'Einstein': '爱因斯坦',
        'Stockholm': '斯德哥尔摩',
        'Allvar Gullstrand': '阿尔瓦·古尔斯特兰德',
        'Royal Swedish Academy of Sciences': '瑞典皇家科学院',
        'Japan': '日本',
        'Gothenburg': '哥德堡',
        'Sweden': '瑞典',
        'Nordic': '北欧'},
 '非人声区间': {'S1': [[2.59125, 2.88375, '紧贴两头']],
           'S2': [[2.54, 2.818667, '紧贴词头'], [7.855, 8.03]],
           'S3': [[2.120083, 2.35, '紧贴词尾'], [3.361375, 3.6, '紧贴词尾']],
           'S8': [[4.745, 4.963333, '紧贴词头'], [9.96, 10.28]],
           'S9': [[3.415, 3.79], [9.0725, 9.135]],
           'S10': [[2.615, 2.85]],
           'S6': [[1.0675, 1.39]]},
 '词尾除阻': {'S3': {'句末': [6.244667, 't']},
          'S4': {'句末': [9.47, 't']},
          'S6': {'1': [1.075, 't']},
          'S9': {'句末': [9.035, 't']}},
 '分段增益dB': {'S11': {'1': 1.0}},
 '除阻加强': {'S15': {'1': [2.35, 2.44, -3.0]}},
 '结尾句': {'S15': {'前段语速': 0.9,
                 '最后一段语速': 0.78,
                 '最后一段前停顿': 0.7,
                 '接点': [116580, 149700],
                 '依据': '全篇结尾句按 07 定下的标准（用户 2026-10-10 同意并要求所有视频统一）：前段 0.9、最后一段“carried there by the man the '
                       'prize had honoured.” 0.78、前面停 0.7 秒。接点由 结尾句接点.py 自动找：0.9 那遍最后一个标点后最长静音（40 ms）的正中 4.857 '
                       's，0.78 那遍（75 ms）的正中 6.237 s，所在帧和两侧各 5 ms 都低于 -55 dB（程序以 08 校准：与人工核实的接点落在同一段静音里）'}},
 '区间声音指纹': {'S1': '626dd55ab0b7',
            'S2': '71fdb9538db3',
            'S3': '924ecc7299dc',
            'S4': '5c22e6e1ab70',
            'S6': '8daae53b2f3a',
            'S8': '139b3e492845',
            'S9': '6df747cd2698',
            'S10': '2e3d799ed1f1',
            'S15': '3149facce3ad'},
 'allow_clash': ['apparent',
                 'Brazil',
                 'Royal',
                 'Revolution',
                 'Askew',
                 'law',
                 'miss',
                 'after all',
                 'looked past'],
 '换行变更已获同意': {'S1': '用户062原话：“在这个地方，这个apparent 标注重点词汇所对应的意思为 '
                    '看似”；落实本篇apparent看似重点，按原T34只拆apparent和vicinity对齐格，原完整中英词序、正文块及音频输入保留。'}}

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from 核对 import 生成并核对
生成并核对(S, out)
